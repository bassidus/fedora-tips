# Credits
This themes base on <b>Arc-Theme</b> </br>
Links : https://github.com/horst3180/arc-theme</br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation

This themes have been test on gnome shell 3.30 & 3.36 </br>

Install themes : 
- Extract Archive File On Directory<i> /usr/share/themes (as root),</i> </br>
- Or Extract Archive File On Directory<i> Home/.themes</i></br>
- Or Extract Archive File On Directory <i>Home/.local/share/themes</i></br>

Download themes : https://www.opendesktop.org/p/1297726/</br>

## Change themes
Debian, Ubuntu (Gnome Desktop) : Use Tweak Tool to change the themes, <i>Gnome Tweak > Appeareance > Themes > Shell</i></br>
